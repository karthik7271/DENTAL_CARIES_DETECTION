# LBJasonCarieJul7 > 2022-07-07 6:28pm
https://universe.roboflow.com/lbjason01/lbjasoncariejul7

Provided by a Roboflow user
License: CC BY 4.0

